package com.o3i.java_sample_library;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class DemoJavaActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo_java);
    }
}